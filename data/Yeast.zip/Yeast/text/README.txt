Due to the large amount of text data, we store the text embedding offline based on biobert

"
python main_biobert
"