import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim
import numpy as np
np.random.seed(1)
torch.manual_seed(1)
torch.cuda.manual_seed_all(1)
torch.backends.cudnn.deterministic = True  
from sklearn.metrics import roc_auc_score
from sklearn.metrics import f1_score
import copy
import math
from torch.nn import Parameter
import scipy.io as scio
import torch.nn.functional as F
import codecs
from numpy.matlib import repmat
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from transformers import AdamW, BertConfig
from pytorch_pretrained_bert import BertTokenizer,BertModel
# from pytorch_pretrained_bert.optimization import BertAdam
# from pytorch_pretrained_bert import BertTokenizer,BertModel
# from pytorch_pretrained_bert.optimization import BertAdam
# from transformers import AdamW
import os
from collections import OrderedDict
import random
from scipy import sparse
import string
from stop_words import get_stop_words    # download stop words package from https://pypi.org/project/stop-words/
from collections import defaultdict
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import esm
import tqdm
# from Evaluation import *
from torch.nn import Conv1d
import torch.utils.data as Data
from torch.autograd import Variable
##########################################################
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu") # cuda
maxlen=512

def biobert(input_ids):
    bert=BertModel.from_pretrained('./BioBert/biobert_v1.1_pubmed_v2.5.1_convert')
    bert=bert.to(DEVICE)
    embeddings=bert(input_ids)
    return embeddings

def Deepbiobert(data,prot_fea,GOterm,AA,batch):
    maxlen=512
    textnum=np.max([len(text) for id,name,sqe,text,label in data])
    print('textnum',textnum)
    tokenizer = BertTokenizer.from_pretrained('./BioBert/biobert_v1.1_pubmed_v2.5.1_convert/vocab.txt', do_lower_case=True)
    for id,name,sqe,text,label in data:
        temp=[]
        count=1
        for a in text:
            text_tokens = tokenizer.tokenize(a)
            samples=["[CLS]"] + text_tokens + ["[SEP]"]
            input_ids = tokenizer.convert_tokens_to_ids(samples)
            if len(input_ids) > maxlen:
                input_ids=input_ids[0:maxlen]
            input_ids=np.array(input_ids)
            input_ids = Variable(torch.LongTensor(input_ids)).to(DEVICE)
            print('input_ids',input_ids.unsqueeze(0).shape)
            embeddings=biobert(input_ids.unsqueeze(0))
            print('embeddings',embeddings[1].shape)
            file4 = './data/YEAST/text/'+GOterm+'_'+str(id)+'_'+str(count)
            input_text=embeddings[1]
            torch.save(input_text,file4)
            count=count+1

